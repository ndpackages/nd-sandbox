
export default interface AesFormatterInterface {

    stringify (cipherParams);

    parse (jsonObj);
}
